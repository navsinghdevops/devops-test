export declare function ApplicationInsightsTests(): void;
