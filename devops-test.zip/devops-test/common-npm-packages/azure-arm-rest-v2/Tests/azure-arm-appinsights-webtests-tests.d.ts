export declare class ApplicationInsightsWebTestsTests {
    static list(): Promise<void>;
    static create(): Promise<void>;
}
