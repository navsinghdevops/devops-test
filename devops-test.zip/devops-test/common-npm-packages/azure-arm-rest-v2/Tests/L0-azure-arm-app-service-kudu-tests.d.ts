export declare function KuduServiceTests(): void;
