export declare function ResourcesTests(): void;
