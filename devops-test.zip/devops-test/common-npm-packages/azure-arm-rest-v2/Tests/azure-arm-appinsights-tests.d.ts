export declare class AzureApplicationInsightsTests {
    static get(): Promise<void>;
    static update(): Promise<void>;
}
