export declare function AzureAppServiceMockTests(): void;
