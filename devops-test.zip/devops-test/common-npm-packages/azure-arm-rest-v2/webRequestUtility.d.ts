declare class WebRequestUtility {
    static getTargetUriFromFwdLink(fwdLink: string): Promise<string>;
}
export = WebRequestUtility;
