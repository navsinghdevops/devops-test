export declare function getSourceTags(): string[];
