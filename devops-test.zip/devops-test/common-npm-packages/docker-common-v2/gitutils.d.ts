export declare function tagsAt(commit: string): string[];
