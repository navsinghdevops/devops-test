import { ToolRunner } from "azure-pipelines-task-lib/toolrunner";
export declare function addDefaultLabelArgs(command: ToolRunner): void;
export declare function getDefaultLabels(addPipelineData?: boolean): string[];
