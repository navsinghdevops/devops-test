export declare function writeFileSync(filePath: string, data: string): number;
export declare function findDockerFile(dockerfilepath: string): string;
