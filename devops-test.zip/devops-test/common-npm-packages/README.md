# Shared Npm packages

These packages are only meant for use by in the box tasks - contributions will only be accepted for those purposes.

Publishing should happen automatically on CI builds, for any issues with this process please reach out to @damccorm and/or the Azure Pipelines Platform team.