import { ToolRunner } from "vsts-task-lib/toolrunner";
export declare function addDefaultLabelArgs(command: ToolRunner): void;
export declare function getDefaultLabels(): string[];
