export declare function findJavaHome(jdkVersion: string, jdkArch: string): string;
export declare function publishJavaTelemetry(taskName: string, javaTelemetryData: any): void;
