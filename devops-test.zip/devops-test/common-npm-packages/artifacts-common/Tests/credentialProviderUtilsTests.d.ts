export declare function credentialProviderUtilsTests(): void;
