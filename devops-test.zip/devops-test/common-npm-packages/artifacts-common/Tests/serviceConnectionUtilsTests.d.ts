export declare function serviceConnectionUtilsTests(): void;
