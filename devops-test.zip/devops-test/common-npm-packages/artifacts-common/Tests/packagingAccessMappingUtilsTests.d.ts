export declare function packagingAccessMappingUtilsTests(): void;
