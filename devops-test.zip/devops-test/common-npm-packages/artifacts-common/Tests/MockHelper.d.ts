import tmrm = require('azure-pipelines-task-lib/mock-run');
export declare function registerLocationHelpersMock(tmr: tmrm.TaskMockRunner): void;
